Content:

Huang2013Test.Rmd: An R Markdown document (which can be considered a script for your testing purpose)
Huang2013Test.html: The output of the script
log and sample folders: Input data
readme.txt: Documentation

Note:

If you want to reorganize the folder structure, change 'fpath' in line 115 of the Rmd file to reflect the new path to data.