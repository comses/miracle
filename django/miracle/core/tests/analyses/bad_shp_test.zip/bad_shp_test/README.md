Shapefile Loader Example
========================

- metadata extractor should only list this README and a `cities.shp`