library("pipeR")
library("ggplot2")

# Create the pipeline
get_cars_data <- function() {
  read.csv(file="../input/cars.csv")
}

transform_data <- function(cars_df) {
  trans_cars_df <- cars_df
  trans_cars_df[,"SqrtSpeed"] <- cars_df$Speed^0.5
  trans_cars_df
}

create_results <- function(trans_cars_df) {
  qplot(x=SqrtSpeed, y=Dist, data=trans_cars_df)
}

write_outputs <- function(result) {
  ggsave(file="../output/test.svg", plot=result, width=10, height=8)
}

# Run the pipeline
get_cars_data() %>>% 
  transform_data %>>% 
  create_results %>>% 
  write_outputs